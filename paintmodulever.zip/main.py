import pygame
import sys
from paint_core import CoolPaint

def main():
    app = CoolPaint()
    app.run()

if __name__ == "__main__":
    main()